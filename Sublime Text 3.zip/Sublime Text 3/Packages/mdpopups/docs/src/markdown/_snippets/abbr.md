*[ST2]: Sublime Text 2
*[ST3]: Sublime Text 3
*[ST4]: Sublime Text 4
